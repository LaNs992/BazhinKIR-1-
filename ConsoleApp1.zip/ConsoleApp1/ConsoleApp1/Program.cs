﻿// See https://aka.ms/new-console-template for more information

{
    //Бажин Кирилл ИП 20-3
    string dol;
    Console.Write("Напишите сумму перевода из долларов в рубли :");
    dol = Console.ReadLine();



    int a = int.Parse(dol);
    int b=100;
    double c=0;
    c = a * b;
    double d = 0.37, f=0;
    Console.WriteLine("Курс в рублях :"+c);
    f = c*(d/100);
    Console.WriteLine("Процент от транзита:" + d + "% ="+f) ;
 
    if (c < 500) {
        Console.WriteLine("Сумма транзакции меньще 500 р,то взимание за перевод 8 р.");
        Console.WriteLine("Итог перевода:" + (c - 8));
            }
    else {
        Console.Write("Итог при переводе в рубялх :");
        c = c - f;
        Console.WriteLine(c);
    }
    
}